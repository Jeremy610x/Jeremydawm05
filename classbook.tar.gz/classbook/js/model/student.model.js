$( document ).ready(function() {
	console.log( "Student model loaded." );
	students[0] = "Alf";
});
